package com.payment;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
//import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.payment.controller.PaymentController;
import com.payment.service.PaymentServiceImpl;



@SpringBootTest
public class PaymentApplicationTests {
	
	
	

	 
  }

	
	
	
